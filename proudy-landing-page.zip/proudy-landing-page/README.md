# Proudy landing page

A Pen created on CodePen.

Original URL: [https://codepen.io/yefry08/pen/QwLBQwz](https://codepen.io/yefry08/pen/QwLBQwz).

Source: Code Alchemy (https://www.youtube.com/watch?v=Jz-jLIby8HI)